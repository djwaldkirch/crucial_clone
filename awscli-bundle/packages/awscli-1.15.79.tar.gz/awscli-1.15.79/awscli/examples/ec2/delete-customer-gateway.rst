**To delete a customer gateway**

This example deletes the specified customer gateway. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-customer-gateway --customer-gateway-id cgw-0e11f167
